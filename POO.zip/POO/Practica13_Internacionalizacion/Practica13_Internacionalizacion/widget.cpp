#include "widget.h"
#include "ui_widget.h"
#include <QFile>
#include <QInputDialog>
#include <QApplication>

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    cambio();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::cambio(){
    ui->cmb_idioma->addItem("Seleccione el idioma");
    ui->cmb_idioma->addItem("Español");
    ui->cmb_idioma->addItem("Ingles");
    connect(ui->cmb_idioma,SIGNAL(currentIndexChanged(int)),this,SLOT(select()));
}
void Widget::select(){
    QTranslator traduccion;
    QString idioma=ui->cmb_idioma->currentText();

    if (idioma.isEmpty()) {
        return;
    }
    qApp->removeTranslator(&traduccion);

    if(idioma == "Ingles"){
        QString archivo= "C:\POO\Practica13_Internacionalizacion\Practica13_Internacionalizacion/ingles.qm";
        if (QFile::exists(archivo)) {
            if (traduccion.load(archivo)) {
                qApp->installTranslator(&traduccion);
                ui->retranslateUi(this);
            } else {
                qWarning() << "No se pudo cargar la traducción desde el archivo:" << archivo;
            }
        } else {
            qWarning() << "El archivo de traducción no existe:" << archivo;
        }
    }else if(idioma == "Español"){
        qApp->removeTranslator(&traduccion);
        ui->retranslateUi(this);
    }
}



