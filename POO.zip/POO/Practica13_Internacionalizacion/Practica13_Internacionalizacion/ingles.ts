<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>Widget</name>
    <message>
        <location filename="widget.ui" line="14"/>
        <source>Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="widget.ui" line="38"/>
        <source>Escoja idioma: </source>
        <translation>Choose the Language:</translation>
    </message>
    <message>
        <location filename="widget.ui" line="48"/>
        <source>Nombre: </source>
        <translation>FirstName:</translation>
    </message>
    <message>
        <location filename="widget.ui" line="58"/>
        <source>Apellido: </source>
        <translation>LastName:</translation>
    </message>
    <message>
        <location filename="widget.ui" line="68"/>
        <source>Genero: </source>
        <translation>Gender:</translation>
    </message>
    <message>
        <location filename="widget.ui" line="77"/>
        <source>Hombre</source>
        <translation>Man</translation>
    </message>
    <message>
        <location filename="widget.ui" line="84"/>
        <source>Mujer</source>
        <translation>Woman</translation>
    </message>
    <message>
        <location filename="widget.ui" line="93"/>
        <source>Nivel: </source>
        <translation>Level:</translation>
    </message>
    <message>
        <location filename="widget.ui" line="103"/>
        <source>Mostrar Mensaje: </source>
        <translation>Show Message:</translation>
    </message>
    <message>
        <location filename="widget.ui" line="110"/>
        <source>Mensaje</source>
        <translation>Message</translation>
    </message>
</context>
</TS>
